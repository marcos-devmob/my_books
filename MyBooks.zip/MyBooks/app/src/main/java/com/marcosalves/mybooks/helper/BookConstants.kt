package com.marcosalves.mybooks.helper

class BookConstants private constructor() {
    object KEY {
        const val BOOK_ID = "bookId"
    }
}