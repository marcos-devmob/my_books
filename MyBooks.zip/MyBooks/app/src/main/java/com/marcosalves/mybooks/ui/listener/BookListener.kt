package com.marcosalves.mybooks.ui.listener

interface BookListener {
    fun onClick(id: Int)
    fun onFavoriteClick(id: Int)
}